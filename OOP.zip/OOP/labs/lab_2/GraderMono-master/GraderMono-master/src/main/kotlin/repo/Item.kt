package repo

interface Item{
    val name: String
}
