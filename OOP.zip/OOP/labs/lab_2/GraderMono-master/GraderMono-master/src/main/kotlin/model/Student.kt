package model

class Student (
    name: String,
    val group: String
) : Person(name) {}