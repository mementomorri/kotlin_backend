package model

enum class Type{
    LECTURE,
    LABORATORY,
    TEST,
    PERSONAL_PROJECT
}