package repo

interface Item {
    var id: Int
}