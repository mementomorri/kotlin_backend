package model



interface Person {
    val id: Int
    val name: String
}