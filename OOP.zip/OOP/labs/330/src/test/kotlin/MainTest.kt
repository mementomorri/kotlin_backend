import model.*
import org.jetbrains.exposed.dao.id.EntityID
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SchemaUtils
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.junit.jupiter.api.AfterAll
import org.junit.jupiter.api.BeforeAll
import org.junit.jupiter.api.TestInstance
import repo.testItemTable
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.fail

private fun addTutorByName(name: String, post: String="Professor", id: Int=-1) {
    if (tutors.read().find { it.name == name } == null){
        if (id == -1) tutors.create(Tutor(name = name, post = post)) else tutors.create(Tutor(name, post, id))
    } else return
}

private fun addStudentByName(name: String, group: String= "Main group", id: Int=-1){
    if (students.read().find { it.name == name } == null){
        if (id == -1) students.create(Student(name = name, group = group)) else students.create(Student(name, group, id))
    } else return
}

private fun addCourseByName( name: String, id: Int=-1){
    if (courses.read().find { it.name == name } == null){
        if (id == -1) courses.create(Course(name = name)) else courses.create(Course(name, id))
    } else return
}

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class MainTest {

    @BeforeAll
    fun init() {
        Database.connect(
                "jdbc:h2:mem:test;DB_CLOSE_DELAY=-1",
                driver = "org.h2.Driver"
        )
        transaction {
            SchemaUtils.create(tutorTable)
            SchemaUtils.create(studentTable)
            SchemaUtils.create(taskTable)
            SchemaUtils.create(courseTable)
            SchemaUtils.create(toplistTable)
            SchemaUtils.create(TypeTable)
            SchemaUtils.create(Grades)
        }

        mapOf(
            "Sheldon" to "Professor",
            "Leonard" to "Professor"
        ).forEach {
            addTutorByName(it.key, it.value)
        }
        mapOf(
            "Howard" to "Footprint on the Moon",
            "Raj" to "Footprint on the Moon",
            "Penny" to "Waitress"
        ).forEach {
            addStudentByName(it.key, it.value)
        }
        listOf(
            "Math",
            "Phis",
            "History"
        ).forEach {
            addCourseByName(it)
        }
        transaction {
            TypeTable.insertAndGetIdItem(Type("Lecture")).value
            true
        }
        transaction {
            TypeTable.insertAndGetIdItem(Type("Laboratory")).value
            true
        }
        val lecType = transaction {
            TypeTable.selectAll().mapNotNull { TypeTable.readResult(it) }
        }.find { it.name == "Lecture" }
        val labType=transaction {
            TypeTable.selectAll().mapNotNull { TypeTable.readResult(it) }
        }.find { it.name == "Laboratory" }

        val math = courses.read().find { it.name =="Math"} ?: fail("Wrong course name")
        courses.read()
                .find {it.name == "Math"}?.run {
            addTutorByName("Sheldon")
            addStudentByName("Howard")
            addStudentByName("Penny")
            tasks.create(Task("Intro", lecType!!.id, math.id))
            tasks.create(Task("UML", lecType!!.id, math.id))
            tasks.create(Task("Uml lab", labType!!.id, math.id, maxValue = 5))
            setGrade("Uml lab", "Howard", 5)
            setGrade("Uml lab", "Penny", 3)
            setGrade("Intro", "Penny", 1)
        }
    }

    @Test
    fun initTest() {
        val math = courses.read().find { it.name=="Math" } ?: fail()
        assertEquals(2, tutors.read().size)
        assertEquals(3, students.read().size)
        assertEquals(2, students.read().filter {
            when (it) {
                is Student -> it.group == "Footprint on the Moon"
                else -> false
            }
        }.size)
        assertEquals("Penny", math.getStudent("Penny")!!.name)
        assertEquals("Howard", math.getStudent("Howard")!!.name)
        assertEquals("Sheldon", math.getTutor("Sheldon")!!.name)
    }

    @Test
    fun setGradeTest() {
        val math = courses.read().find { it.name=="Math" } ?: fail()
        math.setGrade("UML", "Howard", 1)
        val umlTask = tasks.read().find { it.name == "UML" }?: fail()
        assertEquals(
            1,
            math.studentGrades("Howard")!![EntityID(umlTask.id, taskTable)]
        )
    }

    @Test
    fun studentGradesTest() {
        val math = courses.read().find { it.name=="Math" } ?: fail()
        math.setGrade("Intro", "Penny", 1)
        math.setGrade("Uml lab", "Penny", 3)
        math.setGrade("Uml lab", "Penny", 5)
        val pennyGrades = math.studentGrades("Penny")?: fail()
        val umlLabTask = tasks.read().find { it.name == "Uml lab" }?: fail()
        val introTask = tasks.read().find { it.name == "Intro" }?: fail()
        assertEquals(1, pennyGrades[EntityID(introTask.id, taskTable)])
        assertEquals(5, pennyGrades[EntityID(umlLabTask.id, taskTable)])
    }

    @Test
    fun tutorSetToplistTest(){
        val math = courses.read().find { it.name=="Math" } ?: fail()
        math.setGrade("Uml lab", "Howard", 3)
        math.setToplist()
        assertEquals(0.3, math.getRankByName("Penny")?.rank)
        assertEquals(0.4, math.getRankByName("Howard")?.rank)
    }

    @Test
    fun studentOrTutorReadRankTest(){
        val math = courses.read().find { it.name=="Math" } ?: fail()
        math.setToplist()
        val penny = math.getStudent("Penny") ?: fail()
        val howard = math.getStudent("Howard") ?: fail()
        val howardRank = toplist.read().find { it.student_id ==  penny.id && it.course_id == math.id} ?: fail()
        val pennyRank = toplist.read().find { it.student_id ==  howard.id && it.course_id == math.id} ?: fail()
        assertEquals(0.2, howardRank.rank)
        assertEquals(0.22, pennyRank.rank)
    }

    @Test
    fun studentOrTutorReadGradesTest(){
        val math = courses.read().find { it.name=="Math" } ?: fail()
        assertEquals(3, math.getTask("Uml lab")?.getGrade("Penny"))
        assertEquals(5, math.getTask("Uml lab")?.getGrade("Howard"))
    }


    @Test
    fun tutorSetGradeTest(){
        val math = courses.read().find { it.name=="Math" } ?: fail()
        math.setGrade("Intro","Howard",1)
        math.setGrade("Uml lab", "Howard",5)
        assertEquals(1, math.getTask("Intro")?.getGrade("Howard"))
        assertEquals(5, math.getTask("Uml lab")?.getGrade("Howard"))
    }

    @Test
    fun tutorSetTaskTest(){
        val math = courses.read().find { it.name=="Math" } ?: fail()
        val lecType = transaction {
            TypeTable.selectAll().mapNotNull { TypeTable.readResult(it) }
        }.find { it.name == "Lecture" }?: fail()
        val labType=transaction {
            TypeTable.selectAll().mapNotNull { TypeTable.readResult(it) }
        }.find { it.name == "Laboratory" }?: fail()
        tasks.create(Task("test1",lecType.id,math.id))
        tasks.create(Task("test2",lecType.id,math.id))
        tasks.create(Task("test3",labType.id,math.id))
        assertEquals("test1", math.getTask("test1")?.name)
        assertEquals("test2", math.getTask("test2")?.name)
        assertEquals("test3", math.getTask("test3")?.name)
    }

    @Test
    fun tutorAddStudentToCourse(){
        val math = courses.read().find { it.name=="Math" } ?: fail()
        addStudentByName("Bob","Newcomers")
        addStudentByName("Charlie","Newcomers")
        assertEquals("Bob", math.getStudent("Bob")?.name)
        assertEquals("Charlie", math.getStudent("Charlie")?.name)
    }

    @Test
    fun adminSetCourseTest(){
        listOf("Rocket science", "Basic rocket piloting", "Space navigation").forEach {
            addCourseByName(it)
        }
        assertEquals("Rocket science", courses.read().find { it.name=="Rocket science" }?.name)
        assertEquals("Basic rocket piloting", courses.read().find { it.name=="Basic rocket piloting" }?.name)
        assertEquals("Space navigation", courses.read().find { it.name=="Space navigation" }?.name)
    }

    @AfterAll
    fun removeTables(){
        transaction {
            SchemaUtils.drop(tutorTable)
            SchemaUtils.drop(studentTable)
            SchemaUtils.drop(taskTable)
            SchemaUtils.drop(courseTable)
            SchemaUtils.drop(toplistTable)
            SchemaUtils.drop(TypeTable)
            SchemaUtils.drop(Grades)
        }
    }
}