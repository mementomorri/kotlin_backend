package model.main_classes

import model.Reward
import java.time.LocalDate

class Daily (
    override val name: String,
    override val description: String,
    override val difficulty: String,
    override val type: String = "Daily",
    characterId: Int
): Task(name, description, difficulty, type, characterId) {
    var deadline: LocalDate = LocalDate.now().plusDays(1)
    var completionCount: Int = 0
    val rewards: Reward = Reward(2*difficultyToInt,2*difficultyToInt,null)

    fun checkDeadline():Boolean{ //true if there is time left, false otherwise
        return LocalDate.now()<deadline
    }
}