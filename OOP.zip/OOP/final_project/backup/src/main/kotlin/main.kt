import model.abilities.abilityTable
import model.items.itemTable
import model.main_classes.characterTable
import model.main_classes.userTable
import org.jetbrains.exposed.dao.id.IntIdTable
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.statements.UpdateBuilder
import repo.AppRepo

val charactersRepo= AppRepo(characterTable)
val shopRepo= AppRepo(itemTable)
val abilitiesRepo= AppRepo(abilityTable)

class UserCharacter(
        val id:Int = -1,
        val userId: Int,
        val characterId: Int
)

object UserCharacterTable: IntIdTable(){
    val userId= reference("userId", userTable)
    val characterId= reference("characterId", characterTable)

    fun fill (builder: UpdateBuilder<Int>, item:UserCharacter){
        builder[userId] = item.userId
        builder[characterId] = item.characterId
    }

    fun readResult(result: ResultRow): UserCharacter? =
            UserCharacter(
                    result[id].value,
                    result[userId].value,
                    result[characterId].value
            )
}