package repo

import model.items.*
import org.jetbrains.exposed.sql.deleteWhere
import org.jetbrains.exposed.sql.select
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction

class ItemRepo(
        private val table: ItemsTable
) {

    fun create(element: Item)=
        transaction {
            table.insertAndGetIdItem(element).value
            true
        }

    fun read(id: Int, t: Class<Item>)=
            transaction {
                table.select{table.id eq id}
                        .firstOrNull()
                        ?.let {
                            table.readResult(it, t)
                        }
            }

    fun update(id: Int, element: Item)=
            transaction {
                table.updateItem(id, element) >0
            }

    fun delete(id: Int)=
            transaction {
                table.deleteWhere { table.id eq id } >0
            }

//    fun read()=
//            transaction {
//                table.selectAll()
//                        .mapNotNull {
//                            table.readResult(it, Item::class.java)
//                        }
//            }
}