package model

enum class TaskDifficulty {
    VERYEASY,
    EASY,
    MEDIUM,
    HARD,
    VERYHARD
}