package model.main_classes

enum class CharacterClass {
    MAGICIAN,
    WARRIOR,
    ARCHER
}