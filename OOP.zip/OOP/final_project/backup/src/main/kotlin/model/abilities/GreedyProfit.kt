package model.abilities

import model.main_classes.Buff
import model.main_classes.Character

class GreedyProfit (): Ability(
        "Greedy profit",
        "Archer",
        "Archer tries shoot every target possible as quickly as they're swiftness let them",
        40,
        6
) {
    override fun useAbility(character: Character): Boolean {
        return if (character.energyPoints>=energyRequired){
            character.buffs.add(Buff("Greedy",))
            character.energyPoints.minus(40)
            true
        } else false
    }
}

val greedyProfit= GreedyProfit()