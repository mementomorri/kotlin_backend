package model

enum class TaskType{
    HABIT,
    DAILY,
    TODO,
    QUEST
}