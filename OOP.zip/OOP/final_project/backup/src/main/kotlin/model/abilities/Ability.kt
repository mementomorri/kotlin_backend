package model.abilities

import model.main_classes.Character
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.statements.UpdateBuilder
import repo.DefaultIdTable

open class Ability(
    val name: String,
    val characterClass: String,
    val description: String,
    val energyRequired: Int,
    val levelRequired: Int,
    val id: Int = -1
){
    open fun useAbility(character: Character): Boolean=true //true if ability is successfully used, false otherwise
}

class AbilityTable: DefaultIdTable<Ability>(){
    val name= varchar("name", 50)
    val characterClass=  varchar("characterClass",50)
    val description= varchar("description", 255)
    val energyRequired= integer("energyRequired")
    val levelRequired= integer("levelRequired")
    override fun fill(builder: UpdateBuilder<Int>, item: Ability) {
        builder[name]= item.name
        builder[characterClass]= item.characterClass
        builder[description]= item.description
        builder[energyRequired]= item.energyRequired
        builder[levelRequired]= item.levelRequired
    }

    override fun readResult(result: ResultRow): Ability?=
            Ability(
                    result[name],
                    result[characterClass],
                    result[description],
                    result[energyRequired],
                    result[levelRequired],
                    result[id].value
            )
}

val abilityTable= AbilityTable()