package model.items

import model.main_classes.Character
import org.jetbrains.exposed.dao.id.IntIdTable
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.statements.UpdateBuilder
import repo.DefaultIdTable

//open class Item(
//        open var quantity: Int,
//        val name: String,
//        val description: String,
//        val price: Int,
//        open val id: Int= -1
//){
//    open fun useItem(character: Character):Boolean=true // true if item is successfully used, false otherwise
//
//    open fun create(quantity: Int): Item?=Item(quantity, name, description, price)
//}

interface Item{
        var quantity: Int
        val name: String
        val description: String
        val price: Int
        val id: Int
                get() = -1

    fun useItem(character: Character):Boolean // true if item is successfully used, false otherwise

    fun create(quantity: Int): Item?
}

class ItemsTable: IntIdTable(){
    val quantity= integer("quantity")
    val name= varchar("name", 50)
    val description= varchar("description", 510)
    val price= integer("price")

   fun fill(builder: UpdateBuilder<Int>, item: Item){
       builder[quantity]= item.quantity
       builder[name]= item.name
       builder[description]= item.description
       builder[price]= item.price
   }

    fun readResult(result: ResultRow, t: Class<Item>): Item? {
            return t.newInstance().create(result[quantity])
    }
}

//class ItemsTable: DefaultIdTable<Item>(){
//    val quantity= integer("quantity")
//    val name= varchar("name", 50)
//    val description= varchar("description", 510)
//    val price= integer("price")
//    override fun fill(builder: UpdateBuilder<Int>, item: Item) {
//        builder[quantity]= item.quantity
//        builder[name]= item.name
//        builder[description]= item.description
//        builder[price]= item.price
//    }
//
//    override fun readResult(result: ResultRow): Item?=
//        Item(
//            result[quantity],
//            result[name],
//            result[description],
//            result[price],
//            result[id].value
//        )
//}
//
//val itemTable= ItemsTable()