package model.items

import model.main_classes.Character
import model.quests.DustRabbits

class DustRabbitsScroll (
        override var quantity: Int
): Item(quantity,"Dust rabbits scroll", "Some old scroll describing the story of Dust rabbits", 6) {

    override fun useItem(character: Character): Boolean {
        return if (quantity>=1){
            character.quests.add(DustRabbits("Hard",character.id))
            quantity--
            if (quantity<=0) character.inventory.removeIf { it.name =="Dust rabbits scroll" }
            true
        }else false
    }

    override fun create(quantity: Int): Item {
        return DustRabbitsScroll(quantity)
    }
}