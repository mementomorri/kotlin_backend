package model.abilities

import model.main_classes.Character

class BurstsOfFlame(): Ability(
        "Bursts of flame",
        "Magician",
        "Magician focuses at they're target so there is little sparks around it",
        20,
        3
) {
    override fun useAbility(character: Character): Boolean {
        return if (character.energyPoints >= energyRequired){
            character.experiencePoints+=(character.level*3)
            character.checkExperience()
            character.energyPoints.minus(energyRequired)
            true
        } else false
    }
}

val burstsOfFlame = BurstsOfFlame()