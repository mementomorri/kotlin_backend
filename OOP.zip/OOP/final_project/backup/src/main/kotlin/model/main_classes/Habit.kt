package model.main_classes

import model.Reward
import java.time.LocalDate

class Habit(
        override val name: String,
        override val description: String,
        override val difficulty: String,
        override val characterId: Int
): Task(name,description,difficulty,"HABIT",characterId,startDate = LocalDate.now(),completionCount = 0) {
    val rewards: Reward = Reward(2*difficultyToInt,2*difficultyToInt,null)
}