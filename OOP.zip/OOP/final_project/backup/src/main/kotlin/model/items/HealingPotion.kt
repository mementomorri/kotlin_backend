package model.items

import model.main_classes.Character

class HealingPotion (
        override var quantity: Int
): Item(quantity,"Healing potion","This little warm potion restores little amount of your life energy, tastes like cough syrup", 12) {

    override fun useItem(character: Character): Boolean {
        return if (quantity>= 1) {
            character.healthPoints.plus(15)
            if (character.healthPoints> character.maximumHP) character.healthPoints= character.maximumHP
            quantity--
            if (quantity<=0) character.inventory.removeIf { it.name =="Healing potion" }
            true
        } else false
    }

    override fun create(quantity: Int): Item {
        return HealingPotion(quantity)
    }
}