package model.challenges

import model.Reward
import model.main_classes.Character
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.statements.UpdateBuilder

open class Challenge (
    val name: String,
    val description: String
) {
    open val rewards: Reward= Reward(0, 20, null)

    open fun checkChallengeCondition(character: Character): Boolean=true //true if condition passed, false otherwise

    open fun getReward(character: Character): Boolean{ //true if reward added to character, false otherwise
        return if (checkChallengeCondition(character)) {
            rewards.getReward(character)
            true
        } else false
    }
}

class ChallengeTable: Table(){
    val name = varchar("name", 50)
    val description= varchar("description", 255)
    fun fill(builder: UpdateBuilder<Int>, item: Challenge) {
        builder[name] = item.name
        builder[description] = item.description
    }

     fun readResult(result: ResultRow): Challenge? =
             Challenge(
                    result[name],
                    result[description]
            )
}

val challenges= ChallengeTable()