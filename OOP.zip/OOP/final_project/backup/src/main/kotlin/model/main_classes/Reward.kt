package model

import model.items.Item
import model.main_classes.Character

class Reward(
    val experiencePoints: Int,
    val coins: Int,
    val items: List<Item>?
){
    fun getReward(character: Character){
        character.experiencePoints+=experiencePoints
        character.checkExperience()
        character.coins+=coins
        items?.forEach { item ->
            if (character.inventory.find{it.name == item.name} != null) {
                character.inventory.find { it.name ==  item.name}!!.quantity+=item.quantity
            }else character.inventory.add(item)
        }
    }
    fun getGreedyReward(character: Character){
        character.experiencePoints+=(experiencePoints*1.5).toInt()
        character.checkExperience()
        character.coins+= (coins*1.5).toInt()
        if (items!=null) character.inventory.addAll(items)
    }
}