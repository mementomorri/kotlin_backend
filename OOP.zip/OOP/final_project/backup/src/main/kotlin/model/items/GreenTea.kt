package model.items

import model.main_classes.Character

class GreenTea (
        override var quantity: Int
): Item(quantity,"Green tea","A cup of tasty green tea, after a few sips it restores some of your energy",9) {

    override fun useItem(character: Character): Boolean {
        return if (quantity>= 1) {
            character.energyPoints.plus(15)
            if (character.energyPoints> 100) character.energyPoints= 100
            quantity--
            if (quantity<=0) character.inventory.removeIf { it.name =="Green tea" }
            true
        } else false
    }

    override fun create(quantity: Int): Item {
        return GreenTea(quantity)
    }
}