package model.main_classes

import org.jetbrains.exposed.dao.id.IntIdTable
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.statements.UpdateBuilder

open class User (
        open val id: Int= -1,
        open val name: String
)

class UserTable: IntIdTable(){
    val name= varchar("name", 255)

    fun fill(builder: UpdateBuilder<Int>, item: User) {
        builder[name] = item.name
    }

    fun readResult(result: ResultRow): User? =
            User(
                    result[id].value,
                    result[name]
            )
}

val userTable= UserTable()