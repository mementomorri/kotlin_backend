package model.items

import model.main_classes.Character
import model.quests.DishDisaster

class DishDisasterScroll (
        override var quantity: Int
): Item(quantity,"Dish disaster scroll","Some old scroll describing the story of Dish disaster",7) {

    override fun useItem(character: Character): Boolean {
        return if (quantity>=1){
            character.quests.add(DishDisaster("Veryhard",character.id))
            quantity--
            if (quantity<=0) character.inventory.removeIf { it.name =="Dish disaster scroll" }
            true
        }else false
    }

    override fun create(quantity: Int): Item {
        return DishDisasterScroll(quantity)
    }
}