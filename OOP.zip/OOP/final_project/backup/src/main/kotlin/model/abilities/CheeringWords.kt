package model.abilities

import model.main_classes.Character

class CheeringWords(): Ability(
        "Cheering words",
        "Magician",
        "Magician says some inspiring words to other person that heals they're heart or inspires themself by thinking about good things",
        40,
        6
) {
    override fun useAbility(character: Character): Boolean {
        return if (character.maximumHP == character.healthPoints || character.energyPoints< energyRequired){
            false
        } else {
            character.healthPoints.plus((character.level*4))
            if (character.healthPoints>character.maximumHP) character.healthPoints=character.maximumHP
            character.energyPoints.minus(energyRequired)
            true
        }
    }

    fun healOtherPerson(caster: Character, personToHeal: Character): Boolean{
        return if (personToHeal.maximumHP == personToHeal.healthPoints || caster.energyPoints< energyRequired){
            false
        } else {
            personToHeal.healthPoints.plus(caster.level*4)
            if (personToHeal.healthPoints> personToHeal.maximumHP) personToHeal.healthPoints=(personToHeal.maximumHP)
            caster.energyPoints.minus(energyRequired)
            true
        }
    }
}

val cheeringWords= CheeringWords()