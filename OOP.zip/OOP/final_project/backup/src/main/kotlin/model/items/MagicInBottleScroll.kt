package model.items

import model.main_classes.Character
import model.quests.MagicInBottle

class MagicInBottleScroll(
        override var quantity: Int
): Item(quantity, "Magic in bottle scroll", "Some old scroll describing the story of Magic in bottle", 5) {

    override fun useItem(character: Character): Boolean {
        return if (quantity>=1){
            character.quests.add(MagicInBottle("Medium", character.id))
            quantity--
            if (quantity<=0) character.inventory.removeIf { it.name =="Magic in bottle scroll" }
            true
        }else false
    }

    override fun create(quantity: Int): Item {
        return MagicInBottleScroll(quantity)
    }
}