package model.abilities

import model.main_classes.Character

class SwordplayPractice(): Ability(
        "Swordplay practice",
        "Warrior",
        "Warrior focuses on they're swordplay skill while swinging it at the dummy ",
        20,
        3
) {
    override fun useAbility(character: Character): Boolean {
        return if (character.energyPoints>= energyRequired){
            character.experiencePoints+=(character.level*2)
            character.checkExperience()
            character.energyPoints.minus(energyRequired)
            true
        }else false
    }
}

val swordplayPractice= SwordplayPractice()