package model.main_classes

import abilitiesRepo
import model.TaskType
import model.abilities.Ability
import model.items.Item
import model.quests.Quest
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.statements.UpdateBuilder
import org.jetbrains.exposed.sql.transactions.transaction
import repo.DefaultIdTable
import shopRepo
import java.time.LocalDate

class Character (

        override val  name: String,
        val characterClass: String,
        override val id: Int=-1
): User(id, name) {
    var level: Int = 1
    val abilities: ArrayList<Ability> = arrayListOf()
    val buffs: ArrayList<Buff> = arrayListOf()
    var maximumHP:Int = when (CharacterClass.valueOf(this.characterClass.toUpperCase())) {
        CharacterClass.MAGICIAN -> 30
        CharacterClass.ARCHER -> 40
        CharacterClass.WARRIOR -> 50
    }
    var healthPoints: Int = maximumHP
    var energyPoints: Int = 100
    var experiencePoints: Int = 0
    var coins: Int = 0
    val habits: ArrayList<Habit> = arrayListOf()
    val dailies: ArrayList<Daily> = arrayListOf()
    val toDos: ArrayList<ToDo> = arrayListOf()
    val quests: ArrayList<Quest> = arrayListOf()
    val inventory: ArrayList<Item> = arrayListOf()
    private val levelMap: List<Int>
        get() = calculateLevelMap()

    fun refreshTasks(taskType: TaskType){
        when(taskType){
            TaskType.HABIT -> transaction {
                taskTable.selectAll().mapNotNull { taskTable.readResult(it) }
            }.filter { it.characterId == this.id && TaskType.valueOf(it.type.toUpperCase()) == TaskType.HABIT}
                    .forEach {if (!this.habits.contains(Habit(it.name,it.description,it.difficulty,it.characterId))){
                        this.habits.add(Habit(it.name,it.description,it.difficulty,it.characterId)) }}
            TaskType.DAILY -> transaction {
                taskTable.selectAll().mapNotNull { taskTable.readResult(it) }
            }.filter { it.characterId == this.id && TaskType.valueOf(it.type.toUpperCase()) == TaskType.DAILY }
                    .forEach { if (!this.dailies.contains(Daily(it.name,it.description,it.difficulty,it.characterId))){
                        this.dailies.add(Daily(it.name,it.description,it.difficulty,it.characterId)) }}
            TaskType.TODO -> transaction {
                taskTable.selectAll().mapNotNull { taskTable.readResult(it) }
            }.filter { it.characterId == this.id && TaskType.valueOf(it.type.toUpperCase()) == TaskType.TODO }
                    .forEach { if (!this.toDos.contains(ToDo(it.name, it.description, it.difficulty, it.characterId, it.deadline))){
                        this.toDos.add(ToDo(it.name, it.description, it.difficulty, it.characterId, it.deadline)) }}
            TaskType.QUEST -> transaction {
                taskTable.selectAll().mapNotNull { taskTable.readResult(it) }
            }.filter { it.characterId == this.id && TaskType.valueOf(it.type.toUpperCase()) == TaskType.QUEST }
                    .forEach { if (!this.quests.contains(Quest(it.name, it.description, it.difficulty, it.characterId))){
                        this.quests.add(Quest(it.name, it.description, it.difficulty, it.characterId)) }}
        }
    }

    fun addTask(task: Task) {
        refreshTasks(TaskType.valueOf(task.type.toUpperCase()))
        val duplicateCheck= transaction {
            taskTable.selectAll().mapNotNull { taskTable.readResult(it) }
        }.firstOrNull{it.characterId == task.characterId
                && TaskType.valueOf(it.type.toUpperCase()) == TaskType.valueOf(task.type.toUpperCase())
                && it.name == task.name}
        if (duplicateCheck == null) {
            when (TaskType.valueOf(task.type.toUpperCase())) {
                TaskType.HABIT -> if (this.habits.firstOrNull { it.name == task.name } == null) {
                    transaction {
                        taskTable.insert{
                            fill(it, task)
                        }
                        true
                    }
                    if (task is Habit) this.habits.add(task) else {
                        this.habits.add(Habit(task.name, task.description, task.difficulty, task.characterId))
                    }
                }
                TaskType.DAILY -> if (this.dailies.firstOrNull { it.name == task.name } == null) {
                    transaction {
                        taskTable.insert{
                            fill(it, task)
                        }
                        true
                    }
                    if (task is Daily) this.dailies.add(task) else {
                        this.dailies.add(Daily(task.name, task.description, task.difficulty, task.characterId))
                    }
                }
                TaskType.TODO -> if (this.toDos.firstOrNull { it.name == task.name } == null) {
                    transaction {
                        taskTable.insert{
                            fill(it, task)
                        }
                        true
                    }
                    if (task is ToDo) this.toDos.add(task) else {
                        this.toDos.add(ToDo(task.name, task.description, task.difficulty, task.characterId, task.deadline))
                    }
                }
                TaskType.QUEST -> if (this.quests.firstOrNull { it.name == task.name } == null) {
                    transaction {
                        taskTable.insert{
                            fill(it, task)
                        }
                        true
                    }
                    if (task is Quest) this.quests.add(task)else {
                        this.quests.add(Quest(task.name, task.description, task.difficulty, task.characterId))
                    }
                }
            }
        }
    }

    fun removeTask(taskName: String, taskType: TaskType){
        val duplicateCheck= transaction {
            taskTable.selectAll().mapNotNull { taskTable.readResult(it) }
        }.firstOrNull{it.characterId == this.id
                && TaskType.valueOf(it.type.toUpperCase()) == taskType
                && it.name == taskName}
        if (duplicateCheck != null) {
            when (taskType) {
                TaskType.HABIT -> if (this.habits.firstOrNull { it.name == taskName } != null) {
                    transaction {
                        taskTable.deleteWhere { taskTable.characterId eq this@Character.id and (taskTable.name eq taskName) and (taskTable.type eq taskType.toString())} > 0
                    }
                    this.habits.removeIf { it.name == taskName }
                }
                TaskType.DAILY -> if (this.dailies.firstOrNull { it.name == taskName } != null) {
                    transaction {
                        taskTable.deleteWhere { taskTable.characterId eq this@Character.id and (taskTable.name eq taskName) and (taskTable.type eq taskType.toString())} > 0
                    }
                    this.dailies.removeIf { it.name == taskName }
                }
                TaskType.TODO -> if (this.toDos.firstOrNull { it.name == taskName } != null) {
                    transaction {
                        taskTable.deleteWhere { taskTable.characterId eq this@Character.id and (taskTable.name eq taskName) and (taskTable.type eq taskType.toString())} > 0
                    }
                    this.toDos.removeIf { it.name == taskName }
                }
                TaskType.QUEST -> if (this.quests.firstOrNull { it.name == taskName } != null) {
                    transaction {
                        taskTable.deleteWhere { taskTable.characterId eq this@Character.id and (taskTable.name eq taskName) and (taskTable.type eq taskType.toString())} > 0
                    }
                    this.quests.removeIf { it.name == taskName }
                }
            }
        }
    }

    fun completeTask(taskName: String, taskType: TaskType){
        if (buffs.isNotEmpty()) buffs.removeIf { it.duration<LocalDate.now() }
        val isGreedy = this.buffs.firstOrNull { it.name == "Greedy" }
        when(taskType){
            TaskType.HABIT -> if (this.habits.firstOrNull { it.name == taskName } !=null) {
                try {
                    val updateHabit = this.habits.find { it.name == taskName }
                    updateHabit!!.completionCount+=1
                    if (isGreedy==null) {
                        updateHabit!!.rewards.getReward(this)
                    }else {
                        updateHabit!!.rewards.getGreedyReward(this)
                    }
                } catch (e:Exception){
                    throw Exception("can't get Habit with taskName:$taskName while trying to complete it",e)
                }
            }
            TaskType.DAILY -> if (this.dailies.firstOrNull { it.name == taskName } !=null) {
                try {
                    val updateDaily = this.dailies.find { it.name == taskName }
                    if (updateDaily!!.checkDeadline()) {
                        updateDaily.completionCount+= 1
                        if (isGreedy==null) {
                            updateDaily.rewards.getReward(this)
                        }else {
                            updateDaily.rewards.getGreedyReward(this)
                        }
                        updateDaily.deadline.plusDays(1)
                    }else{
                        if (this.buffs.firstOrNull{it.name=="Friendly protection"
                                        ||it.name=="Shield protection"}==null) {
                            this.healthPoints.minus(updateDaily.difficultyToInt * 3)
                            if (updateDaily.difficultyToInt == 4
                                    || updateDaily.difficultyToInt == 5) this.experiencePoints.minus(updateDaily.difficultyToInt)
                        } else return
                    }
                } catch (e:Exception){
                    throw Exception("can't get Daily with taskName:$taskName while trying to complete it",e)
                }
            }
            TaskType.TODO -> if (this.toDos.firstOrNull { it.name == taskName } !=null) {
                try {
                    val updateToDo = this.toDos.find { it.name == taskName }
                    if (updateToDo!!.checkDeadline()) {
                        if (isGreedy==null) {
                            updateToDo.rewards.getReward(this)
                        }else {
                            updateToDo.rewards.getGreedyReward(this)
                        }
                        removeTask(updateToDo.name, TaskType.TODO)
                    } else{
                        if (this.buffs.firstOrNull{it.name=="Friendly protection"
                                        ||it.name=="Shield protection"}==null) {
                            this.healthPoints.minus((updateToDo.difficultyToInt * 3.5).toInt())
                            if (updateToDo.difficultyToInt == 4
                                    || updateToDo.difficultyToInt == 5) this.experiencePoints.minus(updateToDo.difficultyToInt)
                            removeTask(taskName, TaskType.TODO)
                        } else return
                    }
                } catch (e:Exception){
                    throw Exception("can't get ToDo with taskName:$taskName while trying to complete it",e)
                }
            }
            TaskType.QUEST -> if (this.quests.firstOrNull { it.name == taskName } !=null) {
                try {
                    val updateQuest = this.quests.find { it.name == taskName }
                    if (isGreedy==null) {
                        updateQuest!!.rewards.getReward(this)
                    }else {
                        updateQuest!!.rewards.getGreedyReward(this)
                    }
                    removeTask(updateQuest.name, TaskType.QUEST)
                } catch (e:Exception){
                    throw Exception("can't get Quest with taskName:$taskName while trying to complete it",e)
                }
            }
        }
    }

    fun learnAbility(abilityId:Int):Boolean{ //true if ability has been learned successfully, false otherwise
        val ability= abilitiesRepo.read(abilityId)
        return if (ability==null){
            false
        } else{
            if (this.abilities.contains(ability)){
                true
            }else {
                if (this.characterClass == ability.characterClass
                        && this.level >= ability.levelRequired) this.abilities.add(ability)
                true
            }
        }
    }

    private fun calculateLevelMap(): List<Int>{
        val n = 4181
        var t1=8
        var t2=13
        val result = mutableListOf<Int>()

        while (t1<=n){
            result.add(t1)
            val sum = t1+t2
            t1= t2
            t2= sum
        }
        return result.toList()
    }

    fun checkExperience(){
        val i = levelMap.indexOf(levelMap.firstOrNull { it <= this.experiencePoints })
        if (i!= null){
            if (this.level< (i+2)){
                when (CharacterClass.valueOf(this.characterClass.toUpperCase())){
                    CharacterClass.MAGICIAN -> this.maximumHP+= ((i+2) - this.level)*3
                    CharacterClass.ARCHER -> this.maximumHP+= ((i+2) - this.level)*4
                    CharacterClass.WARRIOR -> this.maximumHP+= ((i+2) - this.level)*5
                }
                this.level= i+2
                this.energyPoints= 100
                } else return
        } else return
    }

    fun buyItem(itemId: Int, quantity: Int){
        val item = shopRepo.read(itemId)
        if (item!=null && item.quantity>= quantity) {
            if (this.coins >= (item.price * quantity)){
                if (this.inventory.firstOrNull { it.name == item.name }!= null){
                    this.inventory.find { it.name == item.name }!!.quantity+= quantity
                } else this.inventory.add(item.create(quantity)!!)
            }
        } else return
    }
}

class CharacterTable: DefaultIdTable<Character>(){
    val name = varchar("name", 50)
    val characterClass= varchar("characterClass", 50)
    var level= integer("leve")
    var maximumHP= integer("maximumHP")
    var healthPoints= integer("healthPoints")
    var energyPoints= integer("energyPoints")
    var experiencePoints= integer("experiencePoints")
    var coins= integer("coins")

    override fun fill(builder: UpdateBuilder<Int>, item: Character) {
        builder[name] = item.name
        builder[characterClass] = item.characterClass
        builder[level] = item.level
        builder[maximumHP] = item.maximumHP
        builder[healthPoints] = item.healthPoints
        builder[energyPoints] = item.energyPoints
        builder[experiencePoints] = item.experiencePoints
        builder[coins] = item.coins
    }

    override fun readResult(result: ResultRow): Character? =
            Character(

                    result[name],
                    result[characterClass],
                    result[id].value
            )
}

val characterTable= CharacterTable()