package model.items

import model.main_classes.Character

class Coffee (
        override var quantity: Int
): Item(quantity,"Coffee", "Nice and warm cup of coffee to raise an adventurer spirit", 20, ) {

    override fun useItem(character: Character): Boolean {
        return if (quantity>= 1) {
            character.energyPoints.plus(30)
            if (character.energyPoints> 100) character.energyPoints= 100
            quantity--
            if (quantity<=0) character.inventory.removeIf { it.name =="Coffee" }
            true
        } else false
    }

    override fun create(quantity: Int): Item {
        return Coffee(quantity)
    }
}