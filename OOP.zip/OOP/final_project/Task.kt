package model.main_classes

import model.TaskDifficulty
import model.TaskType
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.statements.UpdateBuilder

open class Task (
    open val name: String,
    open val description: String,
    open val difficulty: String,
    open val type: String,
    open val characterId: Int,
    open val difficultyToInt: Int= when(TaskDifficulty.valueOf(difficulty.toLowerCase())){
            TaskDifficulty.VERYEASY -> 1
            TaskDifficulty.EASY -> 2
            TaskDifficulty.MEDIUM -> 3
            TaskDifficulty.HARD -> 4
            TaskDifficulty.VERYHARD -> 5
        }
)

fun Task.getDifficulty(): TaskDifficulty{
    return TaskDifficulty.valueOf(this.difficulty.toUpperCase())
}

fun Task.getType():TaskType{
    return TaskType.valueOf(this.type.toUpperCase())
}

class TaskTable(): Table(){
    val name= varchar("name", 50)
    val description= varchar("description", 255)
    val difficulty= varchar("difficulty", 10)
    val type= varchar("type", 50)
    val characterId= reference("characterId", characterTable)
    val difficultyToInt= integer("difficultyToInt")

    fun fill(builder: UpdateBuilder<Int>, item: Task) {
        builder[name] = item.name
        builder[description] = item.description
        builder[difficulty] = item.difficulty
        builder[type] = item.type
        builder[characterId] = item.characterId
        builder[difficultyToInt] = item.difficultyToInt
    }

    fun readResult(result: ResultRow): Task? =
            Task(
                    result[name],
                    result[description],
                    result[difficulty],
                    result[type],
                    result[characterId].value,
                    result[difficultyToInt],
            )
}

val tasks= TaskTable()