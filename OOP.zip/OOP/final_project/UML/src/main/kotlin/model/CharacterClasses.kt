package model

enum class CharacterClass {
    Magician,
    Warrior,
    Archer
}