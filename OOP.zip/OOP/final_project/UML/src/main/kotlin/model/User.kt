package model

open class User (
        val name: String
)