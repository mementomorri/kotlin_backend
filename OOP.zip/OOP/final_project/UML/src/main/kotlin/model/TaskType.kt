package model

enum class TaskType{
    Habit,
    Daily,
    ToDo,
    Quest
}