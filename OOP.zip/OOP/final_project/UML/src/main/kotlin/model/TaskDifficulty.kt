package model

enum class TaskDifficulty {
    Very_easy,
    Easy,
    Medium,
    Hard,
    Veru_Hard
}