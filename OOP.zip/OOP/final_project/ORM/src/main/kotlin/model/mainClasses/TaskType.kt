package model.mainClasses

enum class TaskType{
    HABIT,
    DAILY,
    TODO,
    QUEST
}