package model.mainClasses

enum class CharacterClass {
    MAGICIAN,
    WARRIOR,
    ARCHER
}