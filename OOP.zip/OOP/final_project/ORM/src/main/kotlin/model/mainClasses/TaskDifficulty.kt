package model.mainClasses

enum class TaskDifficulty {
    VERYEASY,
    EASY,
    MEDIUM,
    HARD,
    VERYHARD
}