package model.main_classes

enum class TaskType{
    HABIT,
    DAILY,
    TODO,
    QUEST
}