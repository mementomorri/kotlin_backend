package model.main_classes

enum class TaskDifficulty {
    VERYEASY,
    EASY,
    MEDIUM,
    HARD,
    VERYHARD
}