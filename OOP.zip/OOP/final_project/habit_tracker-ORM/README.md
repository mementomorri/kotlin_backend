# ORM

This branch contains information about DB of habit_tracker, source code at "src" folder and ER diagram from "diagrams" folder:

![](https://github.com/mementomorri/habit_tracker/blob/ORM/diagrams/er.png)

At this level of project implementation there is just DB tables, classes and repositories. Here tests run usecase scenarios and check if everything is fine.
